/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul3.main;

import modul3.view.MainMenu;

/**
 *
 * @author Lenovo
 */
public class Main {

    public Main() {
        new MainMenu();

    }

    public static void main(String[] args) {
        new Main();
    }
}
